Ikonki na razie wrzuciłem tu. Jak ktoś będzie dodawał do projektu to najlepiej do DFN/Images/.
Pozd!