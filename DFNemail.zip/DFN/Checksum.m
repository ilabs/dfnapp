//
//  Checksum.m
//  DFN
//
//  Created by Pawel Nuzka on 4/6/12.
//  Copyright (c) 2012 Pawel.Nuzka@gmail.com. All rights reserved.
//

#import "Checksum.h"
#import "Update.h"


@implementation Checksum

@dynamic md5;
@dynamic number;
@dynamic eventsDatesUpdate;
@dynamic eventsUpdate;

@end
