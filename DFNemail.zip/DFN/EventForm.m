//
//  EventForm.m
//  DFN
//
//  Created by Pawel Nuzka on 4/6/12.
//  Copyright (c) 2012 Pawel.Nuzka@gmail.com. All rights reserved.
//

#import "EventForm.h"
#import "Event.h"
#import "EventFormType.h"


@implementation EventForm

@dynamic dbID;
@dynamic event;
@dynamic eventFormType;

@end
