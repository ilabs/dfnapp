//
//  Category.m
//  DFN
//
//  Created by Pawel Nuzka on 4/6/12.
//  Copyright (c) 2012 Pawel.Nuzka@gmail.com. All rights reserved.
//

#import "Category.h"
#import "Event.h"


@implementation Category

@dynamic dbID;
@dynamic lastUpdate;
@dynamic name;
@dynamic year;
@dynamic events;

@end
