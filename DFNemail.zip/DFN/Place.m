//
//  Place.m
//  DFN
//
//  Created by Pawel Nuzka on 4/6/12.
//  Copyright (c) 2012 Pawel.Nuzka@gmail.com. All rights reserved.
//

#import "Place.h"
#import "Event.h"


@implementation Place

@dynamic address;
@dynamic city;
@dynamic dbID;
@dynamic gpsCoordinates;
@dynamic lastUpdate;
@dynamic numberOfFreePlaces;
@dynamic event;

@end
