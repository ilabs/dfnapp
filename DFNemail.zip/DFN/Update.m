//
//  Update.m
//  DFN
//
//  Created by Pawel Nuzka on 4/6/12.
//  Copyright (c) 2012 Pawel.Nuzka@gmail.com. All rights reserved.
//

#import "Update.h"
#import "Checksum.h"


@implementation Update

@dynamic dynamicChecksum;
@dynamic numberOfEventsChecksums;
@dynamic numberOfEventsDatesChecksums;
@dynamic staticChecksum;
@dynamic eventsChecksum;
@dynamic eventsDatesChecksum;

@end
