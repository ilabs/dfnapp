//
//  Organisation.m
//  DFN
//
//  Created by Pawel Nuzka on 4/6/12.
//  Copyright (c) 2012 Pawel.Nuzka@gmail.com. All rights reserved.
//

#import "Organisation.h"
#import "Event.h"


@implementation Organisation

@dynamic dbID;
@dynamic name;
@dynamic events;

@end
