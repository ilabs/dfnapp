//
//  EventDate.m
//  DFN
//
//  Created by Pawel Nuzka on 4/21/12.
//  Copyright (c) 2012 pawel.jankowski@me.com. All rights reserved.
//

#import "EventDate.h"
#import "Event.h"


@implementation EventDate

@dynamic closingHour;
@dynamic day;
@dynamic dbID;
@dynamic lastUpdate;
@dynamic openingHour;
@dynamic event;
@dynamic subscribeEvent;

@end
